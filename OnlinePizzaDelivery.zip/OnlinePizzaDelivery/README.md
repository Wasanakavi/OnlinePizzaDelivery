  
 ## Credential for Admin panel :

> username: **admin**       
> password: **admin**


